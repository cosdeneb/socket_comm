from socket import *
import select, msvcrt
import os
from os.path import exists
import sys
import time
import threading

class Client():

    def __init__(self):
        
        self.counter = 0

        soc = socket(AF_INET, SOCK_STREAM)
        HOST = '192.168.1.9'
        PORT = 9999

        soc.connect((HOST, PORT)) # 내가 접속할 서버의 ip주소와 포트번호를 입력
        print(HOST, '에 접속되었습니다.')

        while True:
            # message = input('보낼 메세지를 입력하세요 : ')
            # if message == 'quit':
            #     break
            
            # soc.send(message.encode('utf-8')) # 메세지 전송
            pass

        soc.close()

        # filename = soc.recv(1024).decode('utf-8') # 파일 이름 전달받음

        # os.chdir(os.path.dirname(__file__)) # 실행 경로를 현재 .py 파일이 위치한 곳(서버의 위치)으로 변경
        # print(os.getcwd())
        # print(Path.cwd())

        #########################################################
        # if not exists(filename):
        #     print('파일 %s 은 서버에 존재하지 않습니다.' %filename)
        #     sys.exit()
        # #########################################################

        # print("파일 %s 를 전송합니다." %filename)
        # with open(filename, 'rb') as f:
        #     try:
        #         data = f.read(1024)
        #         data_byte = 0
        #         while data:
        #             data_byte += soc.send(data)
        #             # self.counter += soc.send(data)
        #             data = f.read(1024)

        #     except Exception as ex:
        #         print(ex)

        # print("%s 파일 전송 완료, 파일 크기 : %d byte" %(filename, data_byte))