from socket import *
import sys, os
import random
import time
import threading
from _thread import *
from os.path import exists
# from Client import Cellular_Client, WiFi_Client


# class Cellular_Client(threading.Thread):
class Cellular_Client():

    def __init__(self):
        super(Cellular_Client, self).__init__()  


    def connecting(self):
        self.soc = socket(AF_INET, SOCK_STREAM)
        HOST = '192.168.1.9' # Cellular ip주소
        # HOST = '127.0.0.1'
        # HOST = '192.168.200.156'
        PORT = 9999
        self.soc.connect((HOST, PORT)) # 내가 접속할 서버의 ip주소와 포트번호를 입력
        print(HOST, PORT, '에 접속되었습니다.')


    def terminal(self):
        self.soc.close()


    def send(self, data, counter):
        
        try: 
            self.soc.send(data)
            counter += len(data)
            return counter

        except Exception as ex:
            print(ex)


# class WiFi_Client(threading.Thread):
class WiFi_Client():

    def __init__(self):
        super(WiFi_Client, self).__init__()

    def connecting(self):
        self.soc = socket(AF_INET, SOCK_STREAM)
        HOST = '192.168.1.9' # Cellular ip주소
        # HOST = '127.0.0.1'
        # HOST = '192.168.200.156'
        PORT = 8888
        self.soc.connect((HOST, PORT)) # 내가 접속할 서버의 ip주소와 포트번호를 입력
        print(HOST, '/', PORT, '에 접속되었습니다.')


    def terminal(self):
        self.soc.close()


    def send(self, data, counter):

        try: 
            self.soc.send(data)
            counter += len(data)
            return counter

        except Exception as ex:
            print(ex)


############################################## main 함수 작동 부분 ################################################

if __name__ == '__main__':

    c1 = Cellular_Client()
    # c1.start()
    # c1.join()

    c2 = WiFi_Client()
    # c2.start()
    # c2.join()

    os.chdir(os.path.dirname(__file__)) # 실행 경로를 현재 .py 파일이 위치한 곳(서버의 위치)으로 변경
    filename = 'image.jpg'
    # filename = 'paraKQC_v1.txt'
    counter = 0

    with open(filename, 'rb') as f:

        try:
            data = f.read(1024)
            # data = f.readline()
            
            if not exists(filename):
                print('파일 %s는 서버에 존재하지 않습니다.' %filename)
                sys.exit()

            while data:
                network_type = random.randint(0, 100)

                if network_type % 2 == 0:
                    print("Network Type : Cellular")
                    c1.connecting()
                    counter = c1.send(data, counter)
                    c1.terminal()

                else : 
                    print("Network Type : WiFi")
                    c2.connecting()
                    counter = c2.send(data, counter)
                    c2.terminal()
                
                # print(data)
                data = f.read(1024)
                # data = f.readline()

        except Exception as ex:
            print(ex)

    print("%s 파일 전송 완료, 파일 크기 : %d byte" %(filename, counter))